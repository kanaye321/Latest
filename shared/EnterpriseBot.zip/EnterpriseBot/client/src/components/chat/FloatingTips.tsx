
import React, { useState, useEffect } from 'react';
import { X, Lightbulb, MessageCircle, Sparkles, Users } from 'lucide-react';

interface Tip {
  id: string;
  icon: React.ReactNode;
  title: string;
  content: string;
  category: 'question' | 'feature' | 'tip';
}

const tips: Tip[] = [
  {
    id: 'specific-questions',
    icon: <MessageCircle className="w-4 h-4" />,
    title: 'Ask Specific Questions',
    content: 'The more specific your question, the better the response. Include context and details.',
    category: 'question'
  },
  {
    id: 'code-help',
    icon: <Sparkles className="w-4 h-4" />,
    title: 'Code Assistance',
    content: 'Ask for code reviews, debugging help, or explanations of programming concepts.',
    category: 'question'
  },
  {
    id: 'markdown-support',
    icon: <Lightbulb className="w-4 h-4" />,
    title: 'Rich Formatting',
    content: 'Responses support markdown formatting including code blocks, lists, and links.',
    category: 'feature'
  },
  {
    id: 'multiple-sessions',
    icon: <Users className="w-4 h-4" />,
    title: 'Multiple Sessions',
    content: 'Create different chat sessions for different topics or projects using the sidebar.',
    category: 'feature'
  },
  {
    id: 'keyboard-shortcuts',
    icon: <Lightbulb className="w-4 h-4" />,
    title: 'Quick Send',
    content: 'Use Ctrl+Enter (or Cmd+Enter) to quickly send your message.',
    category: 'tip'
  },
  {
    id: 'follow-up',
    icon: <MessageCircle className="w-4 h-4" />,
    title: 'Follow-up Questions',
    content: 'Feel free to ask follow-up questions or request clarification on any response.',
    category: 'question'
  }
];

export function FloatingTips() {
  const [currentTip, setCurrentTip] = useState<Tip | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [hasSeenTips, setHasSeenTips] = useState(false);

  useEffect(() => {
    // Check if user has seen tips before
    const seenTips = localStorage.getItem('chat-tips-seen');
    if (seenTips) {
      setHasSeenTips(true);
      return;
    }

    // Show first tip after a delay
    const initialDelay = setTimeout(() => {
      showRandomTip();
    }, 3000);

    // Show tips periodically
    const interval = setInterval(() => {
      if (!hasSeenTips && Math.random() > 0.7) { // 30% chance every interval
        showRandomTip();
      }
    }, 30000); // Every 30 seconds

    return () => {
      clearTimeout(initialDelay);
      clearInterval(interval);
    };
  }, [hasSeenTips]);

  const showRandomTip = () => {
    const randomTip = tips[Math.floor(Math.random() * tips.length)];
    setCurrentTip(randomTip);
    setIsVisible(true);

    // Auto-hide after 8 seconds
    setTimeout(() => {
      setIsVisible(false);
    }, 8000);
  };

  const handleDismiss = () => {
    setIsVisible(false);
    setCurrentTip(null);
  };

  const handleDontShowAgain = () => {
    localStorage.setItem('chat-tips-seen', 'true');
    setHasSeenTips(true);
    setIsVisible(false);
    setCurrentTip(null);
  };

  if (!isVisible || !currentTip) return null;

  const categoryColors = {
    question: 'from-blue-500 to-blue-600',
    feature: 'from-purple-500 to-purple-600',
    tip: 'from-green-500 to-green-600'
  };

  return (
    <div className="fixed bottom-20 right-4 z-50 animate-slide-up">
      <div className="bg-card border border-border rounded-xl shadow-xl max-w-sm p-4 backdrop-blur-sm">
        {/* Header */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <div className={`p-2 rounded-lg bg-gradient-to-r ${categoryColors[currentTip.category]} text-white`}>
              {currentTip.icon}
            </div>
            <h3 className="font-semibold text-sm text-foreground">
              {currentTip.title}
            </h3>
          </div>
          <button
            onClick={handleDismiss}
            className="p-1 text-muted-foreground hover:text-foreground transition-colors rounded-md hover:bg-muted"
            title="Dismiss tip"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
          {currentTip.content}
        </p>

        {/* Actions */}
        <div className="flex items-center justify-between gap-2">
          <button
            onClick={handleDontShowAgain}
            className="text-xs text-muted-foreground hover:text-foreground transition-colors underline"
          >
            Don't show tips
          </button>
          <div className="flex items-center gap-1">
            <Lightbulb className="w-3 h-3 text-yellow-500" />
            <span className="text-xs text-muted-foreground">Tip</span>
          </div>
        </div>
      </div>
    </div>
  );
}
