
import React, { useState, useEffect } from 'react';
import { Bot, Plus, MessageSquare, X, Moon, Sun, XIcon, Sparkles, Clock, Users } from 'lucide-react';
import { useTheme } from '../providers/ThemeProvider';
import type { ChatSession } from '../../types/chat';

// Motivational quotes array
const motivationalQuotes = [
  { text: "The only way to do great work is to love what you do.", author: "Steve Jobs" },
  { text: "Code is like humor. When you have to explain it, it's bad.", author: "Cory House" },
  { text: "First, solve the problem. Then, write the code.", author: "John Johnson" },
  { text: "Experience is the name everyone gives to their mistakes.", author: "Oscar Wilde" },
  { text: "In order to be irreplaceable, one must always be different.", author: "Coco Chanel" },
  { text: "Java is to JavaScript what car is to Carpet.", author: "Chris Heilmann" },
  { text: "The best error message is the one that never shows up.", author: "Thomas Fuchs" },
  { text: "Simplicity is the ultimate sophistication.", author: "Leonardo da Vinci" },
  { text: "Make it work, make it right, make it fast.", author: "Kent Beck" },
  { text: "The most important property of a program is whether it accomplishes the intention of its user.", author: "C.A.R. Hoare" },
  { text: "Programming isn't about what you know; it's about what you can figure out.", author: "Chris Pine" },
  { text: "The only impossible journey is the one you never begin.", author: "Tony Robbins" },
  { text: "Innovation distinguishes between a leader and a follower.", author: "Steve Jobs" },
  { text: "Your limitation—it's only your imagination.", author: "Unknown" },
  { text: "Great things never come from comfort zones.", author: "Unknown" },
  { text: "Success is not final, failure is not fatal: it is the courage to continue that counts.", author: "Winston Churchill" },
  { text: "The way to get started is to quit talking and begin doing.", author: "Walt Disney" },
  { text: "Don't let yesterday take up too much of today.", author: "Will Rogers" },
  { text: "You learn more from failure than from success. Don't let it stop you. Failure builds character.", author: "Unknown" },
  { text: "If you are working on something that you really care about, you don't have to be pushed. The vision pulls you.", author: "Steve Jobs" }
];

// Function to get quote based on current minute
function getCurrentQuote() {
  const now = new Date();
  const minuteOfDay = now.getHours() * 60 + now.getMinutes();
  const quoteIndex = minuteOfDay % motivationalQuotes.length;
  return motivationalQuotes[quoteIndex];
}

interface SidebarProps {
  sessions: ChatSession[];
  activeSessionId: string | null;
  onCreateSession: () => void;
  onSelectSession: (sessionId: string) => void;
  onDeleteSession: (sessionId: string) => void;
  status: string;
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({
  sessions,
  activeSessionId,
  onCreateSession,
  onSelectSession,
  onDeleteSession,
  status,
  isOpen,
  onClose
}: SidebarProps) {
  const { theme, setTheme } = useTheme();
  const [currentQuote, setCurrentQuote] = useState(getCurrentQuote());

  // Auto-refresh quote every minute
  useEffect(() => {
    const updateQuote = () => {
      setCurrentQuote(getCurrentQuote());
    };

    // Update immediately
    updateQuote();

    // Set up interval to update every minute
    const interval = setInterval(updateQuote, 60000);

    return () => clearInterval(interval);
  }, []);

  const handleDeleteSession = (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Delete this chat session?')) {
      onDeleteSession(sessionId);
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
    
    if (diffInHours < 24) {
      return date.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit'
      });
    } else {
      return date.toLocaleDateString([], {
        month: 'short',
        day: 'numeric'
      });
    }
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden backdrop-blur-sm"
          onClick={onClose}
          data-testid="sidebar-overlay"
        />
      )}
      
      {/* Sidebar */}
      <div 
        className={`fixed lg:relative lg:translate-x-0 inset-y-0 left-0 z-50 w-80 bg-gradient-to-b from-card via-card to-muted/10 border-r border-border/50 flex flex-col transition-all duration-500 shadow-2xl ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`} 
        data-testid="sidebar"
      >
        {/* Sidebar Header */}
        <div className="p-6 border-b border-border/30 bg-gradient-to-r from-primary/5 to-transparent">
          <div className="flex items-center gap-4 mb-6">
            <div className="relative">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary via-primary to-emerald-600 flex items-center justify-center shadow-xl border border-primary/20">
                <Bot className="w-7 h-7 text-white drop-shadow-sm" strokeWidth={2.5} />
              </div>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-white dark:border-gray-900 animate-pulse-soft"></div>
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="text-xl font-bold text-foreground truncate bg-gradient-to-r from-foreground to-foreground/80 bg-clip-text">
                AI Assistant
              </h1>
              <p className="text-sm text-muted-foreground truncate flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                Your intelligent companion
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="p-2.5 rounded-xl hover:bg-accent/80 transition-all duration-300 flex-shrink-0 hover:scale-105 active:scale-95" 
                title="Toggle theme"
                data-testid="button-theme-toggle"
              >
                {theme === 'dark' ? (
                  <Sun className="w-5 h-5 text-amber-500" />
                ) : (
                  <Moon className="w-5 h-5 text-blue-600" />
                )}
              </button>
              <button 
                onClick={onClose}
                className="lg:hidden p-2.5 rounded-xl hover:bg-accent/80 transition-all duration-300 flex-shrink-0 hover:scale-105 active:scale-95" 
                title="Close sidebar"
                data-testid="button-close-sidebar"
              >
                <XIcon className="w-5 h-5 text-muted-foreground" />
              </button>
            </div>
          </div>
          
          {/* New Chat Button */}
          <button 
            onClick={onCreateSession}
            className="w-full bg-gradient-to-r from-primary via-primary to-emerald-600 text-white rounded-2xl px-6 py-4 flex items-center justify-center gap-3 hover:shadow-2xl hover:scale-[1.02] hover:-translate-y-0.5 transition-all duration-300 font-semibold shadow-lg border border-primary/20 group"
            data-testid="button-new-chat"
          >
            <Plus className="w-6 h-6 group-hover:rotate-90 transition-transform duration-300" strokeWidth={2.5} />
            <span className="text-base">Start New Chat</span>
          </button>
        </div>

        {/* Stats Section */}
        <div className="px-6 py-4 border-b border-border/30">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/50 dark:to-blue-900/30 rounded-xl p-3 border border-blue-200/50 dark:border-blue-800/30">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span className="text-xs font-medium text-blue-700 dark:text-blue-300">Total Chats</span>
              </div>
              <p className="text-lg font-bold text-blue-800 dark:text-blue-200">{sessions.length}</p>
            </div>
            <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-950/50 dark:to-emerald-900/30 rounded-xl p-3 border border-emerald-200/50 dark:border-emerald-800/30">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span className="text-xs font-medium text-emerald-700 dark:text-emerald-300">Active</span>
              </div>
              <p className="text-lg font-bold text-emerald-800 dark:text-emerald-200">
                {activeSessionId ? '1' : '0'}
              </p>
            </div>
          </div>
        </div>

        {/* Chat Sessions */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="mb-4">
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider px-2 flex items-center gap-2">
              <Users className="w-4 h-4" />
              Recent Conversations
            </h3>
          </div>
          
          <div className="space-y-2" data-testid="chat-sessions">
            {sessions.length === 0 ? (
              <div className="text-center py-12 px-4">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center">
                  <MessageSquare className="w-8 h-8 text-muted-foreground/50" />
                </div>
                <p className="text-sm font-medium text-muted-foreground mb-1">No conversations yet</p>
                <p className="text-xs text-muted-foreground/70">Start a new chat to begin your AI journey</p>
              </div>
            ) : (
              sessions.map((session, index) => (
                <div
                  key={session.id}
                  onClick={() => onSelectSession(session.id)}
                  className={`group relative flex items-center gap-3 p-4 rounded-2xl transition-all duration-300 cursor-pointer hover:shadow-lg hover:-translate-y-0.5 ${
                    activeSessionId === session.id
                      ? 'bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border-2 border-primary/30 shadow-lg scale-[1.02]'
                      : 'hover:bg-gradient-to-r hover:from-accent/50 hover:to-transparent border-2 border-transparent hover:border-border/50'
                  }`}
                  data-testid={`chat-session-${session.id}`}
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <div className={`relative w-11 h-11 rounded-2xl flex items-center justify-center flex-shrink-0 transition-all duration-300 ${
                    activeSessionId === session.id
                      ? 'bg-gradient-to-br from-primary to-primary/80 shadow-lg'
                      : 'bg-gradient-to-br from-muted to-muted/70 group-hover:from-primary/20 group-hover:to-primary/10'
                  }`}>
                    <MessageSquare className={`w-5 h-5 transition-all duration-300 ${
                      activeSessionId === session.id ? 'text-white' : 'text-muted-foreground group-hover:text-primary'
                    }`} />
                    {activeSessionId === session.id && (
                      <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-white dark:border-gray-900 animate-pulse-soft"></div>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className={`font-semibold text-sm truncate transition-colors duration-300 ${
                      activeSessionId === session.id ? 'text-primary' : 'text-foreground group-hover:text-primary'
                    }`}>
                      {session.title}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                      <Clock className="w-3 h-3" />
                      {formatTime(session.createdAt)}
                    </div>
                  </div>
                  
                  <button
                    onClick={(e) => handleDeleteSession(session.id, e)}
                    className="opacity-0 group-hover:opacity-100 p-2 text-muted-foreground hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all duration-300 rounded-xl hover:scale-110 active:scale-95"
                    data-testid={`button-delete-${session.id}`}
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Sidebar Footer */}
        <div className="p-6 border-t border-border/30 space-y-4 bg-gradient-to-t from-muted/10 to-transparent">
          {/* Quote of the Minute */}
          <div className="relative bg-gradient-to-br from-primary/10 via-primary/5 to-transparent rounded-2xl p-4 border border-primary/20 overflow-hidden">
            <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-primary/10 to-transparent rounded-full -translate-y-10 translate-x-10"></div>
            <div className="relative">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-primary" />
                </div>
                <h4 className="text-sm font-bold text-primary">Daily Inspiration</h4>
              </div>
              <blockquote className="text-xs text-foreground/90 italic leading-relaxed font-medium mb-2">
                "{currentQuote.text}"
              </blockquote>
              <cite className="text-xs text-muted-foreground font-medium">
                — {currentQuote.author}
              </cite>
            </div>
          </div>
          
          {/* Status */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-3 h-3 rounded-full shadow-lg ${
                status === 'Ready' 
                  ? 'bg-gradient-to-r from-green-400 to-emerald-500 animate-pulse-soft' 
                  : 'bg-gradient-to-r from-orange-400 to-red-500'
              }`}></div>
              <span data-testid="status-indicator" className="text-sm font-semibold text-foreground">
                {status}
              </span>
            </div>
            <div className="text-xs text-muted-foreground bg-muted/50 px-2 py-1 rounded-lg">
              v2.0
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
