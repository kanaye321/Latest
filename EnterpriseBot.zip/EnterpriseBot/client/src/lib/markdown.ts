function escapeHtml(text: string): string {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

export function renderMarkdown(text: string): string {
  let html = text
    // Code blocks
    .replace(/```(\w+)?\n([\s\S]*?)```/g, (_, lang, code) => {
      const language = escapeHtml(lang || 'javascript');
      const escapedCode = escapeHtml(code);
      return `<pre><code class="language-${language}">${escapedCode}</code></pre>`;
    })
    // Inline code
    .replace(/`([^`]+)`/g, (_, code) => `<code class="bg-muted px-1 py-0.5 rounded text-sm">${escapeHtml(code)}</code>`)
    // Bold
    .replace(/\*\*(.*?)\*\*/g, (_, text) => `<strong>${escapeHtml(text)}</strong>`)
    // Italic
    .replace(/\*(.*?)\*/g, (_, text) => `<em>${escapeHtml(text)}</em>`)
    // Line breaks
    .replace(/\n/g, '<br>')
    // Lists
    .replace(/^\s*[-*+]\s+(.*)$/gm, (_, text) => `<div class="flex items-start gap-2 my-1"><span class="text-primary mt-1">•</span><span>${escapeHtml(text)}</span></div>`)
    // Links (sanitize URL and escape text)
    .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (_, text, url) => {
      const safeUrl = url.replace(/"/g, '&quot;');
      return `<a href="${safeUrl}" target="_blank" rel="noopener noreferrer" class="text-primary hover:underline">${escapeHtml(text)}</a>`;
    })
    // Auto-link URLs (sanitize)
    .replace(/(https?:\/\/[^\s<]+[^<.,:;"')\]\s])/g, (url) => {
      const safeUrl = url.replace(/"/g, '&quot;');
      return `<a href="${safeUrl}" target="_blank" rel="noopener noreferrer" class="text-primary hover:underline">${escapeHtml(url)}</a>`;
    })
    // Images (sanitize URL, only allow http/https)
    .replace(/(https?:\/\/[^\s]+?\.(?:png|jpg|jpeg|gif))/gi, (url) => {
      const safeUrl = url.replace(/"/g, '&quot;');
      return `<img src="${safeUrl}" class="max-w-full border-radius-lg margin-2" alt="Chat image" />`;
    });

  // Table processing
  if (/\|(.+)\|/.test(text)) {
    html = html.replace(/((?:\|.+\|\n)+)/g, (match) => {
      const rows = match.trim().split('\n').map(r => r.trim()).filter(r => r.length > 0);
      if (rows.length < 2) return match;
      
      const headers = rows[0].split('|').map(c => c.trim()).filter(Boolean);
      const bodyRows = rows.slice(2).map(r => r.split('|').map(c => c.trim()).filter(Boolean));
      
      const thead = '<thead><tr>' + headers.map(h => `<th class="bg-primary text-primary-foreground px-3 py-2 text-left">${escapeHtml(h)}</th>`).join('') + '</tr></thead>';
      const tbody = '<tbody>' + bodyRows.map(r => '<tr>' + r.map(c => `<td class="border border-border px-3 py-2">${escapeHtml(c)}</td>`).join('') + '</tr>').join('') + '</tbody>';
      
      return `<div class="overflow-x-auto my-4"><table class="border-collapse w-full text-sm">${thead}${tbody}</table></div>`;
    });
  }

  return html;
}

export function addCopyButtons(element: HTMLElement): void {
  element.querySelectorAll('pre code').forEach((codeBlock) => {
    const pre = codeBlock.parentNode as HTMLElement;
    if (pre.querySelector('.copy-btn')) return; // Already has copy button
    
    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-btn';
    copyBtn.textContent = 'Copy';
    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(codeBlock.textContent || '');
        copyBtn.textContent = '✓ Copied';
        setTimeout(() => copyBtn.textContent = 'Copy', 2000);
      } catch (err) {
        copyBtn.textContent = 'Failed';
        setTimeout(() => copyBtn.textContent = 'Copy', 2000);
      }
    });
    pre.appendChild(copyBtn);
  });
}
