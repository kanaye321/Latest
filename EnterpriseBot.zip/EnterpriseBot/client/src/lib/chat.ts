import { apiRequest } from './queryClient';
import type { ChatSession, ChatMessage } from '../types/chat';

export async function createChatSession(title: string): Promise<ChatSession> {
  const response = await apiRequest('POST', '/api/chat/sessions', { title });
  return response.json();
}

export async function getChatSessions(): Promise<ChatSession[]> {
  const response = await apiRequest('GET', '/api/chat/sessions');
  return response.json();
}

export async function deleteChatSession(sessionId: string): Promise<void> {
  await apiRequest('DELETE', `/api/chat/sessions/${sessionId}`);
}

export async function getChatMessages(sessionId: string): Promise<ChatMessage[]> {
  const response = await apiRequest('GET', `/api/chat/sessions/${sessionId}/messages`);
  return response.json();
}

export async function sendChatMessage(sessionId: string, content: string): Promise<ChatMessage> {
  const response = await apiRequest('POST', `/api/chat/sessions/${sessionId}/messages`, {
    role: 'user',
    content
  });
  return response.json();
}

export async function getAIResponse(sessionId: string, userMessage: string): Promise<ChatMessage> {
  const response = await apiRequest('POST', `/api/chat/sessions/${sessionId}/ai-response`, {
    message: userMessage
  });
  return response.json();
}
