import React, { useState, useEffect } from 'react';
import { Bot, Plus, MessageSquare, X, Moon, Sun, XIcon } from 'lucide-react';
import { useTheme } from '../providers/ThemeProvider';
import type { ChatSession } from '../../types/chat';

// Motivational quotes array
const motivationalQuotes = [
  { text: "The only way to do great work is to love what you do.", author: "Steve Jobs" },
  { text: "Code is like humor. When you have to explain it, it's bad.", author: "Cory House" },
  { text: "First, solve the problem. Then, write the code.", author: "John Johnson" },
  { text: "Experience is the name everyone gives to their mistakes.", author: "Oscar Wilde" },
  { text: "In order to be irreplaceable, one must always be different.", author: "Coco Chanel" },
  { text: "Java is to JavaScript what car is to Carpet.", author: "Chris Heilmann" },
  { text: "The best error message is the one that never shows up.", author: "Thomas Fuchs" },
  { text: "Simplicity is the ultimate sophistication.", author: "Leonardo da Vinci" },
  { text: "Make it work, make it right, make it fast.", author: "Kent Beck" },
  { text: "The most important property of a program is whether it accomplishes the intention of its user.", author: "C.A.R. Hoare" },
  { text: "Programming isn't about what you know; it's about what you can figure out.", author: "Chris Pine" },
  { text: "The only impossible journey is the one you never begin.", author: "Tony Robbins" },
  { text: "Innovation distinguishes between a leader and a follower.", author: "Steve Jobs" },
  { text: "Your limitation—it's only your imagination.", author: "Unknown" },
  { text: "Great things never come from comfort zones.", author: "Unknown" },
  { text: "Success is not final, failure is not fatal: it is the courage to continue that counts.", author: "Winston Churchill" },
  { text: "The way to get started is to quit talking and begin doing.", author: "Walt Disney" },
  { text: "Don't let yesterday take up too much of today.", author: "Will Rogers" },
  { text: "You learn more from failure than from success. Don't let it stop you. Failure builds character.", author: "Unknown" },
  { text: "If you are working on something that you really care about, you don't have to be pushed. The vision pulls you.", author: "Steve Jobs" }
];

// Function to get quote based on current minute
function getCurrentQuote() {
  const now = new Date();
  const minuteOfDay = now.getHours() * 60 + now.getMinutes();
  const quoteIndex = minuteOfDay % motivationalQuotes.length;
  return motivationalQuotes[quoteIndex];
}

interface SidebarProps {
  sessions: ChatSession[];
  activeSessionId: string | null;
  onCreateSession: () => void;
  onSelectSession: (sessionId: string) => void;
  onDeleteSession: (sessionId: string) => void;
  status: string;
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({
  sessions,
  activeSessionId,
  onCreateSession,
  onSelectSession,
  onDeleteSession,
  status,
  isOpen,
  onClose
}: SidebarProps) {
  const { theme, setTheme } = useTheme();
  const [currentQuote, setCurrentQuote] = useState(getCurrentQuote());

  // Auto-refresh quote every minute
  useEffect(() => {
    const updateQuote = () => {
      setCurrentQuote(getCurrentQuote());
    };

    // Update immediately
    updateQuote();

    // Set up interval to update every minute
    const interval = setInterval(updateQuote, 60000);

    return () => clearInterval(interval);
  }, []);

  const handleDeleteSession = (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Delete this chat session?')) {
      onDeleteSession(sessionId);
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
    
    if (diffInHours < 24) {
      return date.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit'
      });
    } else {
      return date.toLocaleDateString([], {
        month: 'short',
        day: 'numeric'
      });
    }
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden backdrop-blur-sm"
          onClick={onClose}
          data-testid="sidebar-overlay"
        />
      )}
      
      {/* Sidebar */}
      <div 
        className={`fixed lg:relative lg:translate-x-0 inset-y-0 left-0 z-50 w-80 bg-card border-r border-border flex flex-col transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`} 
        data-testid="sidebar"
      >
        {/* Sidebar Header */}
        <div className="p-4 sm:p-5 border-b border-border">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-primary to-[var(--gradient-end)] flex items-center justify-center shadow-lg">
              <Bot className="w-6 h-6 text-white" strokeWidth={2.5} />
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="text-base sm:text-lg font-bold text-foreground truncate">AI Assistant</h1>
              <p className="text-xs text-muted-foreground truncate">Your intelligent companion</p>
            </div>
            <button 
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="p-2 rounded-xl hover:bg-accent transition-colors duration-200 flex-shrink-0" 
              title="Toggle theme"
              data-testid="button-theme-toggle"
            >
              {theme === 'dark' ? (
                <Sun className="w-5 h-5 text-muted-foreground" />
              ) : (
                <Moon className="w-5 h-5 text-muted-foreground" />
              )}
            </button>
            <button 
              onClick={onClose}
              className="lg:hidden p-2 rounded-xl hover:bg-accent transition-colors duration-200 flex-shrink-0" 
              title="Close sidebar"
              data-testid="button-close-sidebar"
            >
              <XIcon className="w-5 h-5 text-muted-foreground" />
            </button>
          </div>
          
          {/* New Chat Button */}
          <button 
            onClick={onCreateSession}
            className="w-full bg-gradient-to-r from-primary to-[var(--gradient-end)] text-white rounded-xl px-4 py-3 flex items-center justify-center gap-2 hover:shadow-lg hover:scale-[1.02] transition-all duration-200 font-medium shadow-md"
            data-testid="button-new-chat"
          >
            <Plus className="w-5 h-5" strokeWidth={2.5} />
            <span>New Chat</span>
          </button>
        </div>

        {/* Chat Sessions */}
        <div className="flex-1 overflow-y-auto p-3">
          <div className="space-y-2" data-testid="chat-sessions">
            {sessions.length === 0 ? (
              <div className="text-center py-8 px-4">
                <p className="text-sm text-muted-foreground">No conversations yet</p>
                <p className="text-xs text-muted-foreground mt-1">Start a new chat to begin</p>
              </div>
            ) : (
              sessions.map((session) => (
                <div
                  key={session.id}
                  onClick={() => onSelectSession(session.id)}
                  className={`group flex items-center gap-3 p-3 rounded-xl transition-all duration-200 cursor-pointer ${
                    activeSessionId === session.id
                      ? 'bg-primary/10 border border-primary/30'
                      : 'hover:bg-accent border border-transparent'
                  }`}
                  data-testid={`chat-session-${session.id}`}
                >
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${
                    activeSessionId === session.id
                      ? 'bg-primary/20'
                      : 'bg-muted'
                  }`}>
                    <MessageSquare className={`w-4 h-4 ${
                      activeSessionId === session.id ? 'text-primary' : 'text-muted-foreground'
                    }`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className={`font-medium text-sm truncate ${
                      activeSessionId === session.id ? 'text-primary' : 'text-foreground'
                    }`}>
                      {session.title}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {formatTime(session.createdAt)}
                    </div>
                  </div>
                  <button
                    onClick={(e) => handleDeleteSession(session.id, e)}
                    className="opacity-0 group-hover:opacity-100 p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-all duration-200 rounded-lg"
                    data-testid={`button-delete-${session.id}`}
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-border space-y-4">
          {/* Quote of the Minute */}
          <div className="bg-gradient-to-r from-primary/10 to-[var(--gradient-end)]/10 rounded-xl p-3 border border-primary/20">
            <div className="flex items-start gap-2 mb-2">
              <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-xs">💡</span>
              </div>
              <div className="min-w-0">
                <h4 className="text-xs font-semibold text-primary mb-1">Quote of the Moment</h4>
                <blockquote className="text-xs text-foreground/80 italic leading-relaxed">
                  "{currentQuote.text}"
                </blockquote>
                <cite className="text-xs text-muted-foreground mt-1 block">
                  — {currentQuote.author}
                </cite>
              </div>
            </div>
          </div>
          
          {/* Status */}
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <div className={`w-2 h-2 rounded-full ${
              status === 'Ready' ? 'bg-primary' : 'bg-muted-foreground'
            } animate-pulse-soft`}></div>
            <span data-testid="status-indicator" className="font-medium">{status}</span>
          </div>
        </div>
      </div>
    </>
  );
}
