import { useEffect, useRef } from 'react';
import { renderMarkdown, addCopyButtons } from '../../lib/markdown';
import { Bot, User } from 'lucide-react';
import type { ChatMessage } from '../../types/chat';

declare global {
  interface Window {
    Prism?: {
      highlightAll: () => void;
    };
  }
}

interface MessageListProps {
  messages: ChatMessage[];
  isLoading: boolean;
}

export function MessageList({ messages, isLoading }: MessageListProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  useEffect(() => {
    // Add copy buttons to code blocks after messages update
    const messageElements = document.querySelectorAll('.message-content');
    messageElements.forEach(element => {
      addCopyButtons(element as HTMLElement);
    });

    // Highlight syntax
    if (window.Prism) {
      window.Prism.highlightAll();
    }
  }, [messages]);

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="flex-1 overflow-y-auto px-3 sm:px-6 py-6 space-y-6" data-testid="message-list">
      {/* Welcome Message */}
      {messages.length === 0 && !isLoading && (
        <div className="flex items-center justify-center h-full">
          <div className="max-w-lg text-center space-y-6 px-4">
            <div className="flex justify-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-[var(--gradient-end)] flex items-center justify-center shadow-lg">
                <Bot className="w-10 h-10 text-white" strokeWidth={2} />
              </div>
            </div>
            <div className="space-y-3">
              <h2 className="text-2xl sm:text-3xl font-bold text-foreground">
                Welcome to AI Assistant
              </h2>
              <p className="text-muted-foreground text-sm sm:text-base">
                I'm here to help you with coding, problem-solving, analysis, and much more. Start a conversation by typing a message below.
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              <span className="px-3 py-1.5 bg-primary/10 text-primary text-xs sm:text-sm font-medium rounded-full border border-primary/20">
                💡 Code Help
              </span>
              <span className="px-3 py-1.5 bg-primary/10 text-primary text-xs sm:text-sm font-medium rounded-full border border-primary/20">
                📝 Writing
              </span>
              <span className="px-3 py-1.5 bg-primary/10 text-primary text-xs sm:text-sm font-medium rounded-full border border-primary/20">
                🔍 Analysis
              </span>
              <span className="px-3 py-1.5 bg-primary/10 text-primary text-xs sm:text-sm font-medium rounded-full border border-primary/20">
                🎯 Planning
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Chat Messages */}
      <div className="space-y-4">
        {messages.map((message) => {
          const isUser = message.role === 'user';

          return (
            <div 
              key={message.id} 
              className={`flex gap-3 sm:gap-4 ${isUser ? 'flex-row-reverse' : 'flex-row'} message-enter`}
              data-testid={`message-${message.id}`}
            >
              {/* Avatar */}
              <div className={`flex-shrink-0 w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center shadow-md ${
                isUser 
                  ? 'bg-gradient-to-br from-primary to-[var(--gradient-end)]' 
                  : 'bg-card border-2 border-border'
              }`}>
                {isUser ? (
                  <User className="w-4 h-4 sm:w-5 sm:h-5 text-white" strokeWidth={2.5} />
                ) : (
                  <Bot className="w-4 h-4 sm:w-5 sm:h-5 text-primary" strokeWidth={2.5} />
                )}
              </div>

              {/* Message Bubble */}
              <div className={`flex-1 max-w-[85%] sm:max-w-[75%] space-y-1 ${isUser ? 'items-end' : 'items-start'}`}>
                <div className={`rounded-2xl px-4 py-3 shadow-sm ${
                  isUser
                    ? 'bg-[var(--chat-user-bg)] text-[var(--chat-user-fg)] rounded-tr-sm'
                    : 'bg-[var(--chat-bot-bg)] text-[var(--chat-bot-fg)] border border-[var(--chat-bot-border)] rounded-tl-sm'
                }`}>
                  {isUser ? (
                    <div className="message-content text-sm sm:text-base leading-relaxed whitespace-pre-wrap break-words">
                      {message.content}
                    </div>
                  ) : (
                    <div 
                      className="message-content text-sm sm:text-base leading-relaxed"
                      dangerouslySetInnerHTML={{ 
                        __html: renderMarkdown(message.content) 
                      }}
                    />
                  )}
                </div>
                <div className={`text-xs text-muted-foreground px-1 ${isUser ? 'text-right' : 'text-left'}`}>
                  {formatTime(message.createdAt)}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Typing Indicator */}
      {isLoading && (
        <div className="flex gap-3 sm:gap-4 message-enter">
          <div className="flex-shrink-0 w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-card border-2 border-border flex items-center justify-center shadow-md">
            <Bot className="w-4 h-4 sm:w-5 sm:h-5 text-primary" strokeWidth={2.5} />
          </div>
          <div className="flex-1 max-w-[85%] sm:max-w-[75%]">
            <div className="rounded-2xl rounded-tl-sm px-4 py-3 bg-[var(--chat-bot-bg)] border border-[var(--chat-bot-border)] shadow-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <span className="text-sm">Thinking</span>
                <div className="typing-dots flex gap-1">
                  <span className="w-1.5 h-1.5 bg-primary rounded-full animate-typing"></span>
                  <span className="w-1.5 h-1.5 bg-primary rounded-full animate-typing"></span>
                  <span className="w-1.5 h-1.5 bg-primary rounded-full animate-typing"></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <div ref={messagesEndRef} />
    </div>
  );
}
