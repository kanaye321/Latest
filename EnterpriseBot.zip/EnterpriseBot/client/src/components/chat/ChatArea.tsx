import { Download, Trash2, Menu, MoreVertical } from 'lucide-react';
import { MessageList } from './MessageList';
import { MessageInput } from './MessageInput';
import type { ChatMessage } from '../../types/chat';

interface ChatAreaProps {
  chatTitle: string;
  messages: ChatMessage[];
  isLoading: boolean;
  onSendMessage: (message: string) => void;
  onExportChat?: () => void;
  onClearChat?: () => void;
  onToggleSidebar: () => void;
}

export function ChatArea({
  chatTitle,
  messages,
  isLoading,
  onSendMessage,
  onExportChat,
  onClearChat,
  onToggleSidebar
}: ChatAreaProps) {
  return (
    <div className="flex-1 flex flex-col min-w-0 bg-background">
      {/* Chat Header */}
      <div className="bg-card/50 backdrop-blur-sm border-b border-border px-3 sm:px-6 py-3 sm:py-4 sticky top-0 z-10">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
            <button
              onClick={onToggleSidebar}
              className="lg:hidden p-2 text-muted-foreground hover:text-foreground hover:bg-accent rounded-xl transition-all duration-200 flex-shrink-0"
              title="Toggle sidebar"
              data-testid="button-menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="min-w-0 flex-1">
              <h2 className="text-base sm:text-lg font-bold text-foreground truncate" data-testid="chat-title">
                {chatTitle}
              </h2>
              <p className="text-xs text-muted-foreground hidden sm:block">AI-powered conversation</p>
            </div>
          </div>
          
          <div className="flex items-center gap-1 sm:gap-2 flex-shrink-0">
            {/* Chat Actions */}
            {onExportChat && (
              <button 
                onClick={onExportChat}
                className="p-2 text-muted-foreground hover:text-foreground hover:bg-accent rounded-xl transition-all duration-200" 
                title="Export Chat"
                data-testid="button-export"
              >
                <Download className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
            )}
            {onClearChat && (
              <button 
                onClick={onClearChat}
                className="p-2 text-muted-foreground hover:text-foreground hover:bg-accent rounded-xl transition-all duration-200" 
                title="Clear Chat"
                data-testid="button-clear"
              >
                <Trash2 className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Messages */}
      <MessageList messages={messages} isLoading={isLoading} />

      {/* Message Input */}
      <MessageInput onSendMessage={onSendMessage} disabled={isLoading} />

      {/* Footer */}
      <div className="bg-card/50 backdrop-blur-sm border-t border-border px-4 py-3 text-center">
        <p className="text-xs text-muted-foreground">
          Powered by AI • Built with ❤️ • {new Date().getFullYear()} All rights reserved
        </p>
      </div>
    </div>
  );
}
