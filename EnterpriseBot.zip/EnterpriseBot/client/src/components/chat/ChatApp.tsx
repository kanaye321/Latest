import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Sidebar } from './Sidebar';
import { ChatArea } from './ChatArea';
import { useToast } from '../../hooks/use-toast';
import { 
  getChatSessions, 
  createChatSession, 
  deleteChatSession,
  getChatMessages,
  sendChatMessage,
  getAIResponse
} from '../../lib/chat';
import type { ChatSession, ChatMessage } from '../../types/chat';

export function ChatApp() {
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [status, setStatus] = useState('Ready');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch chat sessions
  const { data: sessions = [], isLoading: sessionsLoading } = useQuery({
    queryKey: ['/api/chat/sessions'],
    queryFn: getChatSessions,
  });

  // Fetch messages for active session
  const { data: messages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ['/api/chat/sessions', activeSessionId, 'messages'],
    queryFn: () => activeSessionId ? getChatMessages(activeSessionId) : Promise.resolve([]),
    enabled: !!activeSessionId,
  });

  // Create new chat session
  const createSessionMutation = useMutation({
    mutationFn: createChatSession,
    onSuccess: (newSession) => {
      queryClient.invalidateQueries({ queryKey: ['/api/chat/sessions'] });
      setActiveSessionId(newSession.id);
      toast({
        title: 'New chat created',
        description: 'Started a new chat session',
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to create new chat session',
        variant: 'destructive',
      });
    },
  });

  // Delete chat session
  const deleteSessionMutation = useMutation({
    mutationFn: deleteChatSession,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/chat/sessions'] });
      if (sessions.length > 1) {
        const remainingSessions = sessions.filter(s => s.id !== activeSessionId);
        setActiveSessionId(remainingSessions[0]?.id || null);
      } else {
        setActiveSessionId(null);
      }
      toast({
        title: 'Chat deleted',
        description: 'Chat session has been deleted',
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to delete chat session',
        variant: 'destructive',
      });
    },
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: ({ sessionId, content }: { sessionId: string; content: string }) =>
      sendChatMessage(sessionId, content),
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: ['/api/chat/sessions', activeSessionId, 'messages'] 
      });
    },
  });

  // Get AI response mutation
  const aiResponseMutation = useMutation({
    mutationFn: ({ sessionId, message }: { sessionId: string; message: string }) =>
      getAIResponse(sessionId, message),
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: ['/api/chat/sessions', activeSessionId, 'messages'] 
      });
      setStatus('Ready');
    },
    onError: () => {
      setStatus('Error');
      toast({
        title: 'Error',
        description: 'Failed to get AI response',
        variant: 'destructive',
      });
    },
  });

  // Auto-select first session if none active
  useEffect(() => {
    if (sessions.length > 0 && !activeSessionId) {
      setActiveSessionId(sessions[0].id);
    }
  }, [sessions, activeSessionId]);

  // Create initial session if none exist
  useEffect(() => {
    if (!sessionsLoading && sessions.length === 0) {
      handleCreateSession();
    }
  }, [sessionsLoading, sessions.length]);

  const handleCreateSession = () => {
    const title = `Chat ${sessions.length + 1}`;
    createSessionMutation.mutate(title);
  };

  const handleSelectSession = (sessionId: string) => {
    setActiveSessionId(sessionId);
  };

  const handleDeleteSession = (sessionId: string) => {
    deleteSessionMutation.mutate(sessionId);
  };

  const handleSendMessage = async (content: string) => {
    if (!activeSessionId) return;

    try {
      setStatus('Sending...');
      
      // Send user message
      await sendMessageMutation.mutateAsync({
        sessionId: activeSessionId,
        content
      });

      // Update session title if it's the first message
      const currentSession = sessions.find(s => s.id === activeSessionId);
      if (currentSession && messages.length === 0) {
        const title = content.slice(0, 30) + (content.length > 30 ? '...' : '');
        // TODO: Update session title API call
      }

      setStatus('Processing...');
      
      // Get AI response
      await aiResponseMutation.mutateAsync({
        sessionId: activeSessionId,
        message: content
      });
      
    } catch (error) {
      setStatus('Error');
      console.error('Error sending message:', error);
    }
  };

  const handleExportChat = () => {
    if (!messages.length) return;
    
    const chatContent = messages.map(msg => 
      `${msg.role.toUpperCase()}: ${msg.content}`
    ).join('\n\n');
    
    const blob = new Blob([chatContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chat-${activeSessionId}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: 'Chat exported',
      description: 'Chat has been downloaded as a text file',
    });
  };

  const handleClearChat = () => {
    if (confirm('Clear all messages in this chat?')) {
      // TODO: Implement clear chat API call
      queryClient.invalidateQueries({ 
        queryKey: ['/api/chat/sessions', activeSessionId, 'messages'] 
      });
    }
  };

  const activeSession = sessions.find(s => s.id === activeSessionId);
  const chatTitle = activeSession?.title || 'Welcome';

  const isLoading = sendMessageMutation.isPending || aiResponseMutation.isPending;

  const handleSelectSessionMobile = (sessionId: string) => {
    handleSelectSession(sessionId);
    setIsSidebarOpen(false);
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden" data-testid="chat-app">
      <Sidebar
        sessions={sessions}
        activeSessionId={activeSessionId}
        onCreateSession={handleCreateSession}
        onSelectSession={handleSelectSessionMobile}
        onDeleteSession={handleDeleteSession}
        status={status}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />
      
      <ChatArea
        chatTitle={chatTitle}
        messages={messages}
        isLoading={isLoading}
        onSendMessage={handleSendMessage}
        onExportChat={handleExportChat}
        onClearChat={handleClearChat}
        onToggleSidebar={() => setIsSidebarOpen(true)}
      />
    </div>
  );
}
