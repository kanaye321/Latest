import { useState, useRef, useEffect } from 'react';
import { Send } from 'lucide-react';

interface MessageInputProps {
  onSendMessage: (message: string) => void;
  disabled?: boolean;
}

export function MessageInput({ onSendMessage, disabled = false }: MessageInputProps) {
  const [message, setMessage] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = () => {
    if (message.trim() && !disabled) {
      onSendMessage(message.trim());
      setMessage('');
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(e.target.value);
    
    // Auto-resize textarea
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 128) + 'px';
  };

  useEffect(() => {
    if (textareaRef.current && !disabled) {
      textareaRef.current.focus();
    }
  }, [disabled]);

  return (
    <div className="bg-card/50 backdrop-blur-sm border-t border-border p-3 sm:p-6 sticky bottom-0">
      <div className="max-w-4xl mx-auto">
        <div className="relative">
          {/* Input Field */}
          <div className="flex items-end gap-2 bg-background border-2 border-border rounded-2xl shadow-lg hover:shadow-xl hover:border-primary/30 transition-all duration-200 focus-within:border-primary focus-within:shadow-xl">
            <textarea 
              ref={textareaRef}
              value={message}
              onChange={handleTextareaChange}
              onKeyDown={handleKeyDown}
              placeholder="Type your message here..."
              rows={1}
              disabled={disabled}
              className="flex-1 bg-transparent px-4 sm:px-5 py-3 sm:py-4 text-sm sm:text-base text-foreground placeholder-muted-foreground focus:outline-none resize-none min-h-[52px] max-h-32 disabled:opacity-50 disabled:cursor-not-allowed"
              data-testid="input-message"
            />
            
            {/* Action Buttons */}
            <div className="flex items-center gap-1 sm:gap-1.5 pr-2 pb-2">
              <button 
                type="button"
                onClick={handleSubmit}
                disabled={!message.trim() || disabled}
                className="p-2 sm:p-2.5 bg-gradient-to-r from-primary to-[var(--gradient-end)] text-white rounded-xl hover:shadow-lg hover:scale-105 transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:scale-100"
                title="Send message (Ctrl+Enter)"
                data-testid="button-send"
              >
                <Send className="w-4 h-4 sm:w-5 sm:h-5" strokeWidth={2.5} />
              </button>
            </div>
          </div>
          
          {/* Helper Text */}
          <div className="flex items-center justify-between mt-2 px-2">
            <div className="flex items-center gap-2">
            </div>
            <div className="hidden sm:flex items-center gap-1.5 text-xs text-muted-foreground">
              <kbd className="px-2 py-0.5 bg-muted rounded-lg font-medium border border-border">Ctrl</kbd>
              <span>+</span>
              <kbd className="px-2 py-0.5 bg-muted rounded-lg font-medium border border-border">Enter</kbd>
              <span>to send</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
