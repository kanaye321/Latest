# Enterprise AI Chat Application

## Overview

This is an enterprise-grade AI chat application built with a modern full-stack architecture. The application provides a conversational interface with support for multiple chat sessions, markdown rendering, syntax highlighting, and theme customization. It features a sidebar for managing chat sessions and a main chat area for conversations with an AI assistant.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React with TypeScript, using Vite as the build tool

**UI Component System**: Shadcn/ui components built on Radix UI primitives with Tailwind CSS for styling

- Component library follows the "New York" style variant
- Uses CSS variables for theming with support for light and dark modes
- Custom color scheme designed for enterprise applications

**State Management**: 
- TanStack Query (React Query) for server state management and API data fetching
- Local React state for UI interactions
- Custom hooks for cross-cutting concerns (mobile detection, toast notifications, theme management)

**Routing**: Wouter for lightweight client-side routing

**Key Features**:
- Multi-session chat management
- Real-time message rendering with markdown support
- Syntax highlighting for code blocks using Prism.js
- Responsive design with mobile-first approach
- Theme switching (light/dark mode)

### Backend Architecture

**Runtime**: Node.js with Express.js framework

**Language**: TypeScript with ES modules

**API Design**: RESTful API structure with the following endpoints:
- `GET /api/chat/sessions` - Retrieve all chat sessions
- `POST /api/chat/sessions` - Create new chat session
- `DELETE /api/chat/sessions/:sessionId` - Delete a chat session
- `GET /api/chat/sessions/:sessionId/messages` - Get messages for a session
- `POST /api/chat/sessions/:sessionId/messages` - Send a new message
- `POST /api/chat/sessions/:sessionId/ai-response` - Get AI response

**Data Validation**: Zod schemas for request/response validation

**Development Setup**: Vite development server with HMR (Hot Module Replacement) for rapid development

### Data Storage

**ORM**: Drizzle ORM for type-safe database operations

**Database**: PostgreSQL (configured for Neon serverless)

**Schema Design**:
- `users` table - User authentication and profile data
- `chat_sessions` table - Chat session metadata with user associations
- `chat_messages` table - Individual messages with role (user/assistant), content, and metadata support

**Current Implementation**: In-memory storage adapter (MemStorage) for demo purposes, with interface designed for easy migration to PostgreSQL

**Migration Strategy**: Schema defined in `shared/schema.ts` with Drizzle Kit configured for PostgreSQL migrations in the `migrations` directory

### External Dependencies

**UI Component Libraries**:
- Radix UI - Accessible, unstyled component primitives (@radix-ui/*)
- Tailwind CSS - Utility-first CSS framework
- class-variance-authority - Type-safe variant styling
- cmdk - Command menu component

**Data Fetching & State**:
- TanStack Query (@tanstack/react-query) - Server state management
- React Hook Form (@hookform/resolvers) - Form validation

**Database & ORM**:
- Drizzle ORM (drizzle-orm) - TypeScript ORM
- @neondatabase/serverless - Neon PostgreSQL serverless driver
- Drizzle Kit (drizzle-kit) - Database migration tooling

**Validation**:
- Zod - TypeScript-first schema validation
- drizzle-zod - Zod schema generation from Drizzle schemas

**Markdown & Syntax Highlighting**:
- Prism.js (via CDN) - Code syntax highlighting
- Custom markdown renderer for chat messages

**Development Tools**:
- @replit/vite-plugin-runtime-error-modal - Development error overlay
- @replit/vite-plugin-cartographer - Replit integration
- @replit/vite-plugin-dev-banner - Development mode indicator

**Build & Development**:
- Vite - Frontend build tool and dev server
- esbuild - Fast JavaScript bundler for server code
- tsx - TypeScript execution for Node.js
- dotenv - Environment variable management

**Utilities**:
- date-fns - Date formatting and manipulation
- nanoid - Unique ID generation
- wouter - Lightweight routing library

**Note**: While Drizzle ORM is configured for PostgreSQL with Neon, the current implementation uses an in-memory storage adapter. The schema and database configuration are production-ready and can be activated by connecting to a PostgreSQL instance.