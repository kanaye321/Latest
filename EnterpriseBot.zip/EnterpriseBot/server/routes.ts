import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { storage } from "./storage";
import {
  insertChatSessionSchema,
  insertChatMessageSchema,
} from "@shared/schema";
import session from "express-session";
import { randomUUID } from "crypto";

// Helper function to save chat messages, assuming it's defined elsewhere or needs to be added.
// For now, let's assume a placeholder function that calls storage.createChatMessage.
async function saveMessage(sessionId: string, role: string, content: string) {
  // In a real application, you might want to enrich this with more metadata
  // or handle different message types.
  const message = await storage.createChatMessage({
    sessionId,
    role,
    content,
    metadata: {}, // Placeholder for metadata
  });
  return message;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Add session middleware
  app.use(session({
    secret: process.env.SESSION_SECRET || 'fallback-secret-key-for-development-only',
    resave: false,
    saveUninitialized: true,
    cookie: { 
      secure: false, // Set to true in production with HTTPS
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
      httpOnly: true
    },
    name: 'sessionId'
  }));

  // Middleware to ensure user has a session ID
  app.use('/api/chat', (req, res, next) => {
    try {
      if (!req.session) {
        console.error('Session not initialized');
        return res.status(500).json({ error: 'Session not initialized' });
      }
      
      if (!req.session.userId) {
        req.session.userId = randomUUID();
        console.log('Created new session for user:', req.session.userId);
      }
      next();
    } catch (error) {
      console.error('Session middleware error:', error);
      res.status(500).json({ error: 'Session error' });
    }
  });

  // Chat Sessions API
  app.get("/api/chat/sessions", async (req, res) => {
    try {
      const userId = req.session.userId;
      console.log('Fetching sessions for user:', userId);
      const sessions = await storage.getChatSessions(userId);
      console.log('Found sessions:', sessions.length);
      res.json(sessions);
    } catch (error) {
      console.error("Error fetching chat sessions:", error);
      res.status(500).json({ error: "Failed to fetch chat sessions" });
    }
  });

  app.post("/api/chat/sessions", async (req, res) => {
    try {
      console.log('Creating session with body:', req.body);
      const { title } = insertChatSessionSchema.parse(req.body);
      const userId = req.session.userId;
      console.log('Creating session for user:', userId, 'with title:', title);
      const session = await storage.createChatSession({ title, userId });
      console.log('Created session:', session);
      res.status(201).json(session);
    } catch (error) {
      console.error("Error creating chat session:", error);
      if (error instanceof z.ZodError) {
        res
          .status(400)
          .json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create chat session" });
      }
    }
  });

  app.delete("/api/chat/sessions/:sessionId", async (req, res) => {
    try {
      const sessionId = req.params.sessionId;
      const userId = req.session.userId;
      
      // Verify user owns this session
      const sessions = await storage.getChatSessions(userId);
      const sessionExists = sessions.find(s => s.id === sessionId);
      
      if (!sessionExists) {
        return res.status(404).json({ error: "Session not found or access denied" });
      }
      
      await storage.deleteChatSession(sessionId);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting chat session:", error);
      res.status(500).json({ error: "Failed to delete chat session" });
    }
  });

  // Chat Messages API
  app.get("/api/chat/sessions/:sessionId/messages", async (req, res) => {
    try {
      const sessionId = req.params.sessionId;
      const userId = req.session.userId;
      
      // Verify user owns this session
      const sessions = await storage.getChatSessions(userId);
      const sessionExists = sessions.find(s => s.id === sessionId);
      
      if (!sessionExists) {
        return res.status(404).json({ error: "Session not found or access denied" });
      }
      
      const messages = await storage.getChatMessages(sessionId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching chat messages:", error);
      res.status(500).json({ error: "Failed to fetch chat messages" });
    }
  });

  app.post("/api/chat/sessions/:sessionId/messages", async (req, res) => {
    try {
      const sessionId = req.params.sessionId;
      const userId = req.session.userId;
      const { role, content, metadata } = insertChatMessageSchema.parse(
        req.body,
      );

      // Verify user owns this session
      const sessions = await storage.getChatSessions(userId);
      const sessionExists = sessions.find(s => s.id === sessionId);
      
      if (!sessionExists) {
        return res.status(404).json({ error: "Session not found or access denied" });
      }

      const message = await storage.createChatMessage({
        sessionId,
        role,
        content,
        metadata,
      });

      res.status(201).json(message);
    } catch (error) {
      console.error("Error creating chat message:", error);
      if (error instanceof z.ZodError) {
        res
          .status(400)
          .json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create chat message" });
      }
    }
  });

  // AI Response API
  app.post("/api/chat/sessions/:sessionId/ai-response", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const { message } = req.body;
      const userId = req.session.userId;

      if (!sessionId || !message) {
        return res
          .status(400)
          .json({ error: "Session ID and message are required" });
      }

      // Verify user owns this session
      const sessions = await storage.getChatSessions(userId);
      const sessionExists = sessions.find(s => s.id === sessionId);
      
      if (!sessionExists) {
        return res.status(404).json({ error: "Session not found or access denied" });
      }

      // Use the exact API key that works in your curl command
      const apiKey = "sk-n62VfNKT5pCPJR3TfLD0MPq0nl_b2ZhxBaTQKJ4Di3Uv";

      console.log("Making Samsung API request...");

      // Call Samsung Agent API exactly like your working curl command
      const agentResponse = await fetch(
        "https://agent.sec.samsung.net/api/v1/run/d98b0949-3362-46b8-947a-16084bb3a710?stream=false",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": apiKey,
          },
          body: JSON.stringify({
            input_type: "chat",
            output_type: "chat",
            input_value: message,
          }),
        },
      );

      if (!agentResponse.ok) {
        const errorData = await agentResponse.text();
        console.error("Samsung Agent API error:", errorData);
        throw new Error(`Samsung API error ${agentResponse.status}: ${errorData}`);
      }

      const agentData = await agentResponse.json();
      console.log("Samsung API full response:", JSON.stringify(agentData, null, 2));
      console.log("Response keys:", Object.keys(agentData));

      // Extract response from Samsung API structure
      let aiResponse = "No response from AI";
      
      try {
        // Samsung API returns response in: outputs[0].outputs[0].results.message.text
        if (agentData.outputs && 
            agentData.outputs[0] && 
            agentData.outputs[0].outputs && 
            agentData.outputs[0].outputs[0] && 
            agentData.outputs[0].outputs[0].results && 
            agentData.outputs[0].outputs[0].results.message && 
            agentData.outputs[0].outputs[0].results.message.text) {
          aiResponse = agentData.outputs[0].outputs[0].results.message.text;
        }
        // Fallback to other possible response field names
        else if (agentData.output_value) {
          aiResponse = agentData.output_value;
        } else if (agentData.output) {
          aiResponse = agentData.output;
        } else if (agentData.result) {
          aiResponse = agentData.result;
        } else if (agentData.response) {
          aiResponse = agentData.response;
        } else if (agentData.message) {
          aiResponse = agentData.message;
        } else if (agentData.content) {
          aiResponse = agentData.content;
        } else if (agentData.text) {
          aiResponse = agentData.text;
        } else if (agentData.data) {
          aiResponse = agentData.data;
        } else if (typeof agentData === 'string') {
          aiResponse = agentData;
        }
      } catch (error) {
        console.error("Error extracting AI response:", error);
        aiResponse = "Error processing AI response";
      }

      console.log("Extracted AI response:", aiResponse);

      // Save AI message to database
      const aiMessage = await saveMessage(sessionId, "assistant", aiResponse);

      res.json(aiMessage);
    } catch (error) {
      console.error("Error getting AI response:", error);
      res.status(500).json({ error: "Failed to get AI response" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
